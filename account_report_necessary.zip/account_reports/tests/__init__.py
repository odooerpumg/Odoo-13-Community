# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import common
from . import test_account_reports_filters
from . import test_account_reports
from . import test_reports
